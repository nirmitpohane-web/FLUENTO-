# Fluento — Final Starter App

Fluento is an original, responsive language-learning web app inspired by common language-learning features. It does not use Duolingo branding or artwork.

## Features
- Spanish, English, and Hindi starter courses
- Stages with unlock progression and checkpoint reviews
- Six questions in each lesson
- XP, hearts, streak display, stage progress, achievements, and daily quests
- Friends Circle demo leaderboard and sample friend profiles
- Ollie-inspired owl theme, mobile/tablet layout, PWA manifest, and basic offline cache
- Local browser saving

## Run on Android tablet
1. Download and extract the ZIP.
2. Upload `index.html`, `manifest.json`, `sw.js`, and `icon.svg` to the root of your GitHub repository.
3. In GitHub, open **Settings → Pages**, choose deploy from your main branch and root folder, then save.
4. Open the published HTTPS GitHub Pages link in Chrome.
5. In Chrome's menu, choose **Install app** or **Add to Home screen**.

You can also test locally by opening `index.html`, but PWA install/offline features work best over HTTPS.

## Honest limitations
- This is a working web app/PWA source package, not a signed Android APK.
- Friends are local demo profiles, not real accounts. Online friends, invites, secure login, cloud sync, and shared leaderboards require a backend.
- Streak display is a starter counter, not yet a full date-aware streak system.
- Course material is starter content and should be expanded and reviewed before public release.
- No voice recognition, AI conversation, payment, or cloud account features are included.


## Ultimate update
Includes extra beginner courses (French, German, Italian, Portuguese, Japanese, Korean), five themed stages per added course, welcome screen, local Fluento ID/stage display, streak/medal display, and a notification-permission control.
Important: IDs are not yet backed by an online account server, so friends cannot look up live progress across devices. Browser notifications while the app is closed require a push service/server and are not guaranteed by this offline PWA. Progress is stored locally on the device.
